package com.blichat.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private val bg = Color.rgb(9, 9, 9)
    private val card = Color.rgb(21, 21, 21)
    private val burgundy = Color.rgb(122, 22, 48)
    private val text = Color.rgb(245, 245, 245)
    private val muted = Color.rgb(155, 155, 155)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun showHome() {
        val root = base()

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 20, 20, 12)
        }
        header.addView(label("Blichat", 30f, burgundy, true), LinearLayout.LayoutParams(0, 60, 1f))
        header.addView(label("⌕", 32f, text).apply {
            gravity = Gravity.CENTER
            setPadding(12, 0, 12, 0)
        })
        header.addView(label("✎", 27f, burgundy).apply {
            gravity = Gravity.CENTER
            setPadding(12, 0, 4, 0)
        })
        root.addView(header)

        val tabs = LinearLayout(this).apply {
            setPadding(16, 0, 16, 8)
        }
        listOf("Чаты", "Звонки", "Контакты").forEachIndexed { i, s ->
            val t = label(s, 15f, if (i == 0) burgundy else muted, i == 0)
            t.gravity = Gravity.CENTER
            tabs.addView(t, LinearLayout.LayoutParams(0, 50, 1f))
        }
        root.addView(tabs)

        val chats = listOf(
            Triple("Алина", "Ты уже видел новый трек? 🎵", "12:29"),
            Triple("Макс", "Скинь фото, где ты был 📸", "12:15"),
            Triple("Лучшие 🔥", "Кирилл: Где встретимся?", "11:43"),
            Triple("Вика", "Поняла, спасибо!", "10:22"),
            Triple("Дима", "Голосовое сообщение", "09:48"),
            Triple("Избранное", "Фото", "Вчера"),
            Triple("Blichat News", "Обновление приложения уже доступно!", "Пн")
        )

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        chats.forEach { (name, msg, time) ->
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(20, 10, 20, 10)
                isClickable = true
            }

            val avatar = TextView(this).apply {
                text = name.take(1)
                textSize = 19f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(burgundy)
                }
            }
            row.addView(avatar, LinearLayout.LayoutParams(54, 54))

            val middle = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 0, 8, 0)
            }
            middle.addView(label(name, 17f, text, true))
            middle.addView(label(msg, 14f, muted))
            row.addView(middle, LinearLayout.LayoutParams(0, 64, 1f))

            row.addView(label(time, 12f, muted).apply { gravity = Gravity.TOP })

            list.addView(row)
        }

        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(8, 6, 8, 10)
            setBackgroundColor(card)
        }

        val buttons = listOf("💬\nЧаты", "📞\nЗвонки", "+", "👥\nКонтакты", "👤\nПрофиль")
        buttons.forEachIndexed { i, s ->
            val b = label(s, if (i == 2) 28f else 12f, if (i == 0) burgundy else text, i == 0)
            b.gravity = Gravity.CENTER
            b.setPadding(6, 8, 6, 8)
            b.setOnClickListener {
                when (i) {
                    0 -> showHome()
                    1 -> showSimple("Звонки", "История звонков появится здесь")
                    2 -> showCreateMenu()
                    3 -> showSimple("Контакты", "Поиск друзей и новых контактов")
                    4 -> showSimple("Профиль", "Твой профиль Blichat")
                }
            }
            bottom.addView(b, LinearLayout.LayoutParams(0, 62, 1f))
        }

        root.addView(bottom)
        setContentView(root)
    }

    private fun showSimple(title: String, subtitle: String) {
        val root = base()
        val top = label(title, 28f, burgundy, true).apply { setPadding(20, 24, 20, 10) }
        root.addView(top)
        root.addView(label(subtitle, 16f, muted).apply { setPadding(20, 10, 20, 20) })
        setContentView(root)
    }

    private fun showCreateMenu() {
        val root = base()
        root.addView(label("Создать", 28f, burgundy, true).apply { setPadding(20, 24, 20, 20) })

        listOf(
            "📷  Фото",
            "🎥  Видео",
            "📝  Пост",
            "📖  История",
            "🎬  Reels",
            "💬  Новый чат"
        ).forEach { item ->
            root.addView(label(item, 18f, text).apply {
                setPadding(24, 18, 24, 18)
                setOnClickListener { Toast.makeText(this@MainActivity, item, Toast.LENGTH_SHORT).show() }
            })
        }

        root.addView(label("‹ Назад", 16f, burgundy).apply {
            setPadding(24, 24, 24, 24)
            setOnClickListener { showHome() }
        })
        setContentView(root)
    }
}
