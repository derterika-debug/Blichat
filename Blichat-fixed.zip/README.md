# Blichat

Blichat is an Android prototype combining ideas from a social feed and a messenger.

## Build APK on GitHub

This project intentionally does NOT depend on a `gradlew` file.

GitHub Actions installs Gradle 8.7 and runs:

    gradle assembleDebug

Steps:
1. Upload the contents of this ZIP to the root of the GitHub repository.
2. Open Actions.
3. Select Build APK.
4. Press Run workflow.
5. After the green check, open Artifacts.
6. Download Blichat-debug.

Important: do not upload the ZIP as a single file inside the repository. Upload the folders and files contained in the ZIP.
