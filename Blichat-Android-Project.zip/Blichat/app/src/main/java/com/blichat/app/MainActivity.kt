package com.blichat.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val burgundy = Color.rgb(123, 21, 48)
    private val bg = Color.rgb(9, 9, 9)
    private val white = Color.WHITE
    private val gray = Color.rgb(167,167,173)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }

    private fun base(): LinearLayout {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(20,28,20,12) }
        return root
    }
    private fun tv(text:String,size:Float,color:Int=white,bold:Boolean=false): TextView = TextView(this).apply { this.text=text; textSize=size; setTextColor(color); if(bold) typeface=android.graphics.Typeface.DEFAULT_BOLD; setPadding(4,4,4,4) }
    private fun btn(text:String): Button = Button(this).apply { this.text=text; setTextColor(white); background=getDrawable(com.blichat.app.R.drawable.bg_burgundy); isAllCaps=false; textSize=15f; stateListAnimator=null }

    private fun showHome(){
        base();
        val head=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        head.addView(tv("Blichat",30f,white,true), LinearLayout.LayoutParams(0,60,1f))
        val search=btn("⌕"); head.addView(search,LinearLayout.LayoutParams(56,56)); root.addView(head)
        root.addView(tv("Чаты",18f,gray,true))
        val chats=listOf("Алексей" to "Привет! Как дела?", "Марина" to "Ты сегодня свободна?", "Blichat Team" to "Добро пожаловать в Blichat 🚀")
        chats.forEachIndexed{ i,p->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(12,12,8,12);background=getDrawable(R.drawable.bg_surface)}
            val avatar=TextView(this).apply{ text=p.first.take(1);textSize=20f;setTextColor(white);gravity=Gravity.CENTER;setBackgroundColor(burgundy)}
            row.addView(avatar,LinearLayout.LayoutParams(52,52)); val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,0,0,0)}
            col.addView(tv(p.first,17f,white,true)); col.addView(tv(p.second,14f,gray)); row.addView(col,LinearLayout.LayoutParams(0,76,1f)); row.setOnClickListener{showChat(p.first)}
            val lp=LinearLayout.LayoutParams(-1,76);lp.setMargins(0,8,0,0);root.addView(row,lp)
        }
        val spacer=Space(this);root.addView(spacer,LinearLayout.LayoutParams(1,0,1f))
        val nav=LinearLayout(this).apply{gravity=Gravity.CENTER}
        listOf("Чаты","Контакты","Профиль").forEachIndexed{idx,s-> val b=btn(s); b.setOnClickListener{if(idx==2)showProfile()}; nav.addView(b,LinearLayout.LayoutParams(0,54,1f)) }
        root.addView(nav); setContentView(root)
    }
    private fun showChat(name:String){
        base(); val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}; val back=btn("‹");back.setOnClickListener{showHome()};top.addView(back,LinearLayout.LayoutParams(52,52));top.addView(tv(name,22f,white,true),LinearLayout.LayoutParams(0,60,1f));top.addView(btn("☎"),LinearLayout.LayoutParams(52,52));root.addView(top)
        val messages=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        messages.addView(tv("Сегодня",13f,gray),LinearLayout.LayoutParams(-1,40));
        addBubble(messages,"Привет! 👋",false);addBubble(messages,"Привет! Это Blichat.",true)
        root.addView(messages,LinearLayout.LayoutParams(-1,0,1f))
        val input=EditText(this).apply{hint="Сообщение...";setHintTextColor(gray);setTextColor(white);background=getDrawable(R.drawable.bg_input);setPadding(18,0,18,0)}
        val send=btn("➤");send.setOnClickListener{if(input.text.isNotBlank()){addBubble(messages,input.text.toString(),true);input.text.clear()}}
        val bar=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL};bar.addView(input,LinearLayout.LayoutParams(0,54,1f));bar.addView(send,LinearLayout.LayoutParams(60,54));root.addView(bar);setContentView(root)
    }
    private fun addBubble(parent:LinearLayout,text:String,mine:Boolean){val t=tv(text,15f);t.setPadding(16,12,16,12);t.setBackgroundColor(if(mine)burgundy else Color.rgb(35,35,35));val row=LinearLayout(this);row.gravity=if(mine)Gravity.END else Gravity.START;row.addView(t,LinearLayout.LayoutParams(-2,-2));val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);parent.addView(row,lp)}
    private fun showProfile(){base();root.addView(tv("Профиль",30f,white,true));root.addView(tv("Наталья",22f,white,true));root.addView(tv("Ваш аккаунт Blichat",15f,gray));val edit=btn("Редактировать профиль");root.addView(edit,LinearLayout.LayoutParams(-1,54));root.addView(tv("\nНастройки\nУведомления\nКонфиденциальность\nБезопасность",17f,white));val back=btn("← Назад");back.setOnClickListener{showHome()};root.addView(back);setContentView(root)}
}
